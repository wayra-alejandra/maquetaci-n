function toggleMenu() {
    const navLinks = document.querySelector('.nav-links'); // Selecciona el contenedor del menú
    navLinks.classList.toggle('show'); // Alterna la clase 'show' para mostrar/ocultar el menú
}